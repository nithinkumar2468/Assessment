import './Design.css';
import React, { useEffect, useState } from "react";
function Design() {
    return (
                        <div className='cen'>
                        <div className="spinner">
                            <span>Loading...</span>
                            <div className="half-spinner"></div>
                        </div>
                        </div>
    );
}
 
export default Design;