package com.infinite.controller;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.infinite.daoimpl.ProductImpl;
import com.infinite.pojo.Product;

@Controller
public class Update {
	private ApplicationContext con; 
	
	@RequestMapping(value="/update", method = RequestMethod.POST)
	public String update(@ModelAttribute("bean") Product e, Model m){
		con = new ClassPathXmlApplicationContext("ApplicationContext.xml");
		ProductImpl obj = con.getBean("dao", ProductImpl.class);
		System.out.println("here");
		obj.updateData(e);
		String ProductName = e.getProductName();
		int Price = e.getPrice();
		int Quantity = e.getQuantity();
		int SubTotal = e.getSubTotal();
		System.out.println("here2");
		obj.updateData(e);
		m.addAttribute("msg","Record Updated");
		
		/*@SuppressWarnings("rawtypes")
		List list=obj.*/
		return "updated";
		
	}
	
	@RequestMapping(value="/delete", method = RequestMethod.POST)
	public String delete(@ModelAttribute("bean") Product e, Model m){
		con = new ClassPathXmlApplicationContext("ApplicationContext.xml");
		ProductImpl obj = con.getBean("dao", ProductImpl.class);
		obj.deleteData(e);
		int id = e.getId();
		m.addAttribute("msg","Record Deleted Succesfully..!");
		
		/*@SuppressWarnings("rawtypes")
		List list=obj.*/
		return "deleted";
		
	}
	@RequestMapping(value="/arun", method = RequestMethod.POST)
	public String arun(){
		return "updation";
	}
	


}
