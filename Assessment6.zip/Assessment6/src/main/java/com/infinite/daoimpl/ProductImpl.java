package com.infinite.daoimpl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.web.bind.annotation.RequestMapping;

import com.infinite.daohelper.DaoHelper;
import com.infinite.pojo.Product;

/**
 * @author nithinko
 *
 */
public class ProductImpl {
	static Session sessionObj;
	static SessionFactory sessionFactoryObj;
	private Configuration con;
	private Transaction t;

	// private Session sessionObj;
	public void saveData(Product e) {
		con = new Configuration().configure("hibernate.cfg.xml");
		sessionFactoryObj = con.buildSessionFactory();
		sessionObj = sessionFactoryObj.openSession();
		t = sessionObj.beginTransaction();
		sessionObj.save(e);
		t.commit();

	}

	public void createRecord(Product e) {
		// TODO Auto-generated method stub
		// Getting Session Object From SessionFactory

		try {
			sessionObj = DaoHelper.buildSessionFactory().openSession();
			// Getting Transaction Object From Session Object
			sessionObj.beginTransaction();
			Product st = (Product) sessionObj.get(Product.class, e.getId());
			st.setProductName(st.getProductName());
			st.setPrice(st.getPrice());
			st.setQuantity(st.getQuantity());
			st.setSubTotal(st.getSubTotal());
			/*
			 * sessionObj.update(StudentName); sessionObj.update(RollNumber);
			 * sessionObj.update(Course);
			 */
			sessionObj.update(st);
			sessionObj.save(st);
			sessionObj.getTransaction().commit();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				sessionObj.close();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

	public void deleteData(Product e) { // creating deleteData method to //
										// deleting from db
		con = new Configuration().configure("hibernate.cfg.xml");
		sessionFactoryObj = con.buildSessionFactory();
		sessionObj = sessionFactoryObj.openSession();
		t = sessionObj.beginTransaction();
		Product st = (Product) sessionObj.get(Product.class, e.getId());
		sessionObj.delete(st);
		t.commit();

	}

	public void updateData(Product e) {
		con = new Configuration().configure("hibernate.cfg.xml");
		sessionFactoryObj = con.buildSessionFactory();
		sessionObj = sessionFactoryObj.openSession();
		t = sessionObj.beginTransaction();
		Product obj=(Product)sessionObj.get(Product.class,e.getId());
		obj.setProductName(e.getProductName());
		obj.setPrice(e.getPrice());
		obj.setQuantity(e.getQuantity());
		obj.setSubTotal(e.getSubTotal());
		sessionObj.update(obj);
		t.commit();
	}

}

