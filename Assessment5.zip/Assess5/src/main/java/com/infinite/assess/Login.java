package com.infinite.assess;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.infinite.hikari.HikariDB;



/**
 * @author nithinko
 *
 */
@Controller
public class Login {
	//private static final Logger logger = Logger.getLogger(Login.class);
	
	//login mapper get's called after successfully registered for validation
		@RequestMapping("/login")
			public String login(HttpServletRequest request, HttpServletResponse response) {
			//PropertyConfigurator.configure("Log4j.properties");
				Connection con = null;
				String name = request.getParameter("name");
				String password = request.getParameter("password");
				try {
					DataSource datasource = HikariDB.getDataSource();     //data source connection 
					con = datasource.getConnection();
					PreparedStatement ps = con.prepareStatement("select * from register where name=?");
					ps.setString(1,name);
					ResultSet rs = ps.executeQuery();
					while (rs.next()) {
						if (rs.getString(1).equals(name)) {                  //for validation
							if (rs.getString(3).equals(password)) {
								return "welcome";
							} else {
								return "invalid";
							}
						} else {
							return "invalid";
						}
					}
				} catch (SQLException e) {
					System.out.println(e);
				} catch (Exception e1) {
					System.out.println(e1);
				}
				return "invalid";
			}	
		}
