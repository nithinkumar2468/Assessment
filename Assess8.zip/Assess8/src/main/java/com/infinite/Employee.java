package com.infinite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @nithin
 */
@SpringBootApplication     //Springbootapplication
public class Employee {
	public static void main(String[] args) {
		SpringApplication.run(Employee.class, args);
	}
}