import React from './React.png';
import './App.css';
import Design from './Design';
 
function App() {
  return (
    <div className='bgcol'>
      <div className='text'>
    <div className="App">
      <header >
        <img src={React} alt="logo" width="20%" height="20%"/>
      </header>
    </div>
    <div className='body'>
    <center>
    <p>LOADING</p>
    <p>SCREEN</p>
    <p>REACT</p>
    </center>
    </div>
    </div>
    <center>
    <Design/>
    </center>
    </div>
  );
}
 
export default App;